  
$(document).ready(function(){
   //Logic goes here
   var main = $("#main");
 
$('#btngetAccInfo').click(function(){
	 
	 var address = $('#txtAdd').val();
	 
	$.ajax({
   	url: 'http://dcm10.hallo.cloud:3000/api/dimcoin/getAccountInfoByAddress/'+address,
   	type: "GET",
   	dataType: 'JSON',
   	success: function(response){
   		main.empty();
   				 var listItem =
   				
   				'<p><ul>'+
   				'<p><li><b>Address: </b>'+ response.data.account.address +'</li><p/>' +
   				'<p><li><b>harvestedBlocks: </b>'+ response.data.account.harvestedBlocks +'</li><p/>' +
   				'<p><li><b>Importance: </b>'+ response.data.account.importance +'</li><p/>' +
   				'<p><li><b>vestedBalance: </b>'+ response.data.account.vestedBalance +'</li><p/>' +
				'<p><li><b>publicKey: </b>'+ response.data.account.publicKey +'</li><p/>'+
				'</p></ul>'
   				
			
   				;
					main.append(listItem);
   		}
   	});
});
   
});




$(document).ready(function(){
   //Logic goes here
   var mains = $("#mains");
 
$('#btngetTransaction').click(function(){
	 
	 var address = $('#txtAll').val();
	 
	$.ajax({
   	url: 'http://dcm10.hallo.cloud:3000/api/dimcoin/Alltransactions/'+address,
   	type: "GET",
   	dataType: 'JSON',
	
   	success: function(response){
		
		mains.empty();
		
		
   		for(var i = 0; i < response.length; i++){
   				 var listItems =
   				
   				'<p><ul>'+
   				'<p><li><b>Address: </b>'+ response.data.account[i].address +'</li><p/>' +
   				'<p><li><b>harvestedBlocks: </b>'+ response.data.account[i].harvestedBlocks +'</li><p/>' +
   				'<p><li><b>Importance: </b>'+ response.data.account[i].importance +'</li><p/>' +
   				'<p><li><b>vestedBalance: </b>'+ response.data.account[i].vestedBalance +'</li><p/>' +
				'<p><li><b>publicKey: </b>'+ response.data.account[i].publicKey +'</li><p/>'+
				'</p></ul>'
   				
			
   				;
					mains.append(listItems);
					
		}
   	}
   	});
});
   
});





